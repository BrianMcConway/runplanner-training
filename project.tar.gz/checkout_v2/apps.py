from django.apps import AppConfig


class CheckoutV2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'checkout_v2'
