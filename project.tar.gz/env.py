import os

os.environ["SECRET_KEY"] = "pMnzGwO1WxkoccuRzwXaRZWuHz0l0EHq"
os.environ["DATABASE_URL"] = "postgresql://neondb_owner:f3Yskady2ugH@ep-crimson-water-a2zj5p7o.eu-central-1.aws.neon.tech/crop_relay_radar_814083"
os.environ["EMAIL_HOST_USER"] = "brianbioenergy@gmail.com"
os.environ["EMAIL_HOST_PASS"] = "brbatplnsauysfoq"
os.environ["STRIPE_PUBLIC_KEY"] = "pk_test_51QA8ZIRrLNE4hTc2Cey5ZG1JcQDaZzaXxD6hJ14FnscOhkIRb9eVHF0qlgIEjTCXLK3yRYnNNG6J2TcxOKBZznzm003wJkgSXX"
os.environ["STRIPE_SECRET_KEY"] = "sk_test_51QA8ZIRrLNE4hTc2M1HLoYbLzOkaAynZTVxOZVFq2CNC2QKPes5JVPsalfNLbJxtrweu33Qh9mDW8FqfS9kgO6UJ00UCUMyVOX"
os.environ["STRIPE_WEBHOOK_SECRET"] = "whsec_x0o6yaWUr8bmA89Qw1wLEBnLxun6YFbH"

